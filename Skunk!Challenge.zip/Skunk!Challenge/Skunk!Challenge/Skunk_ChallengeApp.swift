//
//  Skunk_ChallengeApp.swift
//  Skunk!Challenge
//
//  Created by Sudowe, Yuki - Student on 10/3/24.
//

import SwiftUI

@main
struct Skunk_ChallengeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
