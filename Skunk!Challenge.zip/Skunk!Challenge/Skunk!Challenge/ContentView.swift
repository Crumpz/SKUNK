//
//  ContentView.swift
//  Skunk!Challenge
//
//  Created by Sudowe, Yuki - Student on 10/3/24.
//

import SwiftUI
import AVFoundation // Import for music playback

struct ContentView: View {
    
    @State private var players: [PlayerProfile] = [
        PlayerProfile(name: "Player 1", avatar: "😎"),
        PlayerProfile(name: "Player 2", avatar: "🤓"),
        PlayerProfile(name: "Player 3", avatar: "🧐"),
        PlayerProfile(name: "Player 4", avatar: "😜")
    ]
    @State private var activated = true
    @State private var used = false
    @State private var currentPlayerIndex = 0
    @State private var currentRoundScore = 0
    @State private var dice1 = 1
    @State private var dice2 = 1
    @State private var gameOver = false
    @State private var timerRunning = false
    @State private var timeLeft = 45
    @State private var timer: Timer?
    @State private var currentGameMode: GameMode = .normal
    
    // Music Player Instance
    @State private var audioPlayer: AVAudioPlayer?
    
    var body: some View {
        ZStack {
            Color.blue.opacity(0.3).edgesIgnoringSafeArea(.all)
            
            VStack(spacing: 20) {
                Text("Skunk!")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .foregroundColor(.white)
                    .shadow(radius: 5)
                    .padding(.top, 30)
                
                Spacer().frame(height: 20)
                
                // Display Current Player Info
                VStack {
                    Text("Current Player: \(players[currentPlayerIndex].name)")
                        .font(.title)
                        .foregroundColor(.white)
                        .padding(.vertical, 5)
                    
                    Text(players[currentPlayerIndex].avatar)
                        .font(.system(size: 70))
                }
                
                // Player Scores Section
                VStack(spacing: 12) {
                    ForEach(players) { player in
                        HStack {
                            Text("\(player.name):")
                                .font(.headline)
                                .foregroundColor(.white)
                            
                            Spacer()
                            
                            Text("\(player.score)")
                                .font(.title2)
                                .foregroundColor(.yellow)
                        }
                        .padding(.vertical, 10)
                        .padding(.horizontal, 20)
                        .background(Color.green)
                        .cornerRadius(15)
                        .shadow(radius: 5)
                    }
                }
                .padding(.horizontal, 20)
                
                Spacer().frame(height: 20)
                
                // Dice Display
                HStack(spacing: 40) {
                    DiceView(diceValue: dice1)
                    DiceView(diceValue: dice2)
                }
                .padding(.bottom, 20)
                
                // Current Round Score
                Text("Round Score: \(currentRoundScore)")
                    .font(.title2)
                    .foregroundColor(.white)
                    .padding(.vertical, 10)
                    .padding(.horizontal, 20)
                    .background(Color.orange)
                    .cornerRadius(15)
                    .shadow(radius: 5)
                
                Spacer().frame(height: 20)
                
                // Roll, Hold, Skunkblocker Buttons
                HStack(spacing: 20) {
                    Button(action: { rollDice() }) {
                        Text("Roll Dice")
                            .font(.title2)
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(Color.yellow)
                            .foregroundColor(.black)
                            .cornerRadius(15)
                            .shadow(radius: 5)
                    }
                    
                    Button(action: { holdScore() }) {
                        Text("Hold")
                            .font(.title2)
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(Color.red)
                            .foregroundColor(.white)
                            .cornerRadius(15)
                            .shadow(radius: 5)
                    }
                    
                    // Skunkblocker Button
                    Button(action: { useSkunkblocker() }) {
                        Text("Skunkblocker")
                            .foregroundStyle(players[currentPlayerIndex].usedSkunblocker ?
                                             Color.gray.opacity(0) :
                                                Color.white)
                            .font(.title2)
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(players[currentPlayerIndex].usedSkunblocker ?
                                        Color.gray.opacity(0) :
                                Color.purple)
                            .foregroundColor(.white)
                            .cornerRadius(15)
                            .shadow(radius: 5)
                            .disabled(players[currentPlayerIndex].usedSkunblocker)
                    }
                }
                .padding(.horizontal, 30)
                
                Spacer().frame(height: 20)
                
                // Game Mode Picker and Timer Display
                VStack {
                    Text("Select Game Mode")
                        .font(.headline)
                        .foregroundColor(.white)
                    
                    Picker("Game Mode", selection: $currentGameMode) {
                        Text("Normal").tag(GameMode.normal)
                        Text("Double Skunk").tag(GameMode.doubleSkunk)
                        Text("Risk It").tag(GameMode.riskIt)
                        Text("Timed").tag(GameMode.timed)
                    }
                    .pickerStyle(SegmentedPickerStyle())
                    .padding(.horizontal, 30)
                    
                    if currentGameMode == .timed {
                        Text("Time Left: \(timeLeft) seconds")
                            .font(.title2)
                            .foregroundColor(.white)
                            .padding(.top, 10)
                    }
                }
                
                Spacer()
                
                if gameOver {
                    Text("Game Over! Winner: \(getWinner().name) with \(getWinner().score) points!")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(.red)
                        .padding()
                    
                    Button("Play Again") { resetGame() }
                        .font(.title)
                        .padding()
                        .background(Color.green)
                        .foregroundColor(.white)
                        .cornerRadius(15)
                        .shadow(radius: 5)
                        .padding(.bottom, 20)
                }
            }
        }
        .onAppear {
            playMusic() // Start playing music when the view appears
        }
        .onDisappear {
            stopMusic() // Stop music when the view disappears
        }
    }
    
    func rollDice() {
        // Roll two dice and update the state variables
        dice1 = Int.random(in: 1...6)
        dice2 = Int.random(in: 1...6)
        
        switch currentGameMode {
        case .normal:
            if dice1 == 1 || dice2 == 1 {
                if players[currentPlayerIndex].usedSkunblocker {
                    players[currentPlayerIndex].usedSkunblocker = true
                    currentRoundScore += dice1 + dice2
                    nextPlayer()
                } else {
                    currentRoundScore = 0
                    nextPlayer()
                }
            } else {
                currentRoundScore += dice1 + dice2
            }
            
        case .doubleSkunk:
            if dice1 == 1 && dice2 == 1 {
                if players[currentPlayerIndex].usedSkunblocker {
                    players[currentPlayerIndex].usedSkunblocker = true
                    currentRoundScore += dice1 + dice2
                } else {
                    players[currentPlayerIndex].score = 0
                    currentRoundScore = 0
                    nextPlayer()
                }
            } else if dice1 == 1 || dice2 == 1 {
                currentRoundScore = 0
                nextPlayer()
            } else {
                currentRoundScore += dice1 + dice2
            }
            
        case .riskIt:
            if dice1 == 1 || dice2 == 1 || dice1 == 2 || dice2 == 2 {
                currentRoundScore = 0
                nextPlayer()
            } else {
                currentRoundScore += dice1 + dice2
            }
            
        case .timed:
            if dice1 == 1 || dice2 == 1 {
                if players[currentPlayerIndex].usedSkunblocker {
                    players[currentPlayerIndex].usedSkunblocker = true
                    currentRoundScore += dice1 + dice2
                } else {
                    currentRoundScore = 0
                    nextPlayer()
                }
            } else {
                currentRoundScore += dice1 + dice2
            }
            if !timerRunning {
                startTimer()
            }
        }
    }
    
    func holdScore() {
        players[currentPlayerIndex].score += currentRoundScore
        currentRoundScore = 0
        if players[currentPlayerIndex].score >= 100 {
            gameOver = true
        } else {
            nextPlayer()
        }
        stopTimer()
    }
    
    // Skunkblocker Usage
    func useSkunkblocker() {
        if !players[currentPlayerIndex].usedSkunblocker {
            players[currentPlayerIndex].usedSkunblocker = true
        }
    }
    
    func nextPlayer() {
        currentPlayerIndex = (currentPlayerIndex + 1) % players.count
        stopTimer()
    }
    
    // Timer-related methods
    func startTimer() {
        timerRunning = true
        timeLeft = 45
        timer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { _ in
            timeLeft -= 1
            if timeLeft <= 0 {
                nextPlayer()
            }
        }
    }
    
    func stopTimer() {
        timerRunning = false
        timer?.invalidate()
        timer = nil
    }
    
    // Reset the game state
    func resetGame() {
        gameOver = false
        currentPlayerIndex = 0
        currentRoundScore = 0
        players = players.map {
            var newPlayer = $0
            newPlayer.score = 0
            newPlayer.usedSkunblocker = false // Reset Skunkblocker usage
            return newPlayer
        }
        stopTimer()
        stopMusic() // Stop music on game reset
        playMusic() // Restart music
    }
    
    // Get the player with the highest score
    func getWinner() -> PlayerProfile {
        return players.max(by: { $0.score < $1.score })!
    }
    
    // Play background music
    func playMusic() {
        if let path = Bundle.main.path(forResource: "background_music", ofType: "mp3") {
            let url = URL(fileURLWithPath: path)
            do {
                audioPlayer = try AVAudioPlayer(contentsOf: url)
                audioPlayer?.numberOfLoops = -1 // Infinite loop
                audioPlayer?.play()
            } catch {
                print("Error loading music: \(error.localizedDescription)")
            }
        }
    }
    
    // Stop background music
    func stopMusic() {
        audioPlayer?.stop()
    }
}

// Player Profile Model
struct PlayerProfile: Identifiable {
    let id = UUID()
    var name: String
    var avatar: String
    var score: Int = 0
    var usedSkunblocker: Bool = false
}

// Game Mode Enumeration
enum GameMode {
    case normal, doubleSkunk, riskIt, timed
}

// Dice View
struct DiceView: View {
    let diceValue: Int

    var body: some View {
        Image(systemName: "die.face.\(diceValue)")
            .resizable()
            .frame(width: 200, height: 200)
            .background(Color.white)
            .aspectRatio(1, contentMode: .fit)
            .frame(width: 150, height: 150)
            .padding()
            .cornerRadius(20)
            .shadow(radius: 5)
    }
}

// Preview
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}




#Preview {
    ContentView()
}


//struct DiceView: View {
//    let diceValue: Int
//    
//    var body: some View {
//        Image(systemName: "die.face.\(diceValue)")
//            .resizable()
//            .frame(width: 200, height: 200)
//            .background(Color.white)
//            .aspectRatio(1, contentMode: .fit)
//            .frame(width: 150, height: 150)
//            .padding()
//            .cornerRadius(20)
//            .shadow(radius: 5)
//    }
//}
